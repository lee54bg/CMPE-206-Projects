package com.networkdesign.cmpe;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	
	public static void main(String[] args) {	
		PrintWriter out;
		BufferedReader input;
		int portNum = Integer.parseInt(args[0]);
		
		try
        {
//            InetAddress serverAddress = InetAddress.getByName("localhost");
//            System.out.println("server ip address: " + serverAddress.getHostAddress());
//            Socket socket = new Socket("192.168.29.181", portNum);
			Socket socket = new Socket("127.0.0.1", portNum);
            
            out		= new PrintWriter(socket.getOutputStream(), true);
            input	= new BufferedReader(new InputStreamReader(socket.getInputStream()));
            
            out.println("Hello Server");
            
            String cmdArgs[];
            
            while(true) {
            	System.out.print(">");
    			
    			String cmdPrmpt = input.readLine();
    			cmdArgs = cmdPrmpt.split(" ");
    			
    			System.out.println(cmdPrmpt);
    			
    			if(cmdArgs[0].toLowerCase().equals("exit")) {
    				System.out.println("Terminating Program");
    				break;
    			}
    		}

            
            input.close();
            out.close();
            socket.close();
                       
        }
        catch(UnknownHostException e1)
        {
            System.out.println("Unknown host exception " + e1.toString());
        }
        catch(IOException e2)
        {
            System.out.println("IOException " + e2.toString());
        }
        catch(IllegalArgumentException e3)
        {
            System.out.println("Illegal Argument Exception " + e3.toString());
        }
        catch(Exception e4)
        {
            System.out.println("Other exceptions " + e4.toString());
        }
	}
}
