package com.networkdesign.cmpe;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientThread extends Thread {
	
	Socket client = null;
	
	public ClientThread(Socket client) {
		this.client = client;
	}
	
	public void run() {
		try {
			PrintWriter out = new PrintWriter(client.getOutputStream(), true);
	        out.println("Hello  client!");
	        BufferedReader input = new BufferedReader(new InputStreamReader(client.getInputStream()));
	        String clientInput = input.readLine();
	        System.out.println(clientInput);
	        input.close();
	        out.close();
	        client.close();
	    } catch (Exception e) {
	        System.out.println(e.toString());
	    }
	}
}
