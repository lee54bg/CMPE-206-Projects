package com.networkdesign.cmpe;

public class HammingDistance {


	public static void main(String args[]) {
		String bit[] =  {
			"000111",
			"001000",
			"010100",
			"011011",
			"100010",
			"101101",
			"110001",
			"111110"
		};
		
//		String packetData = "01000111 11100011 01111110 11100000";
//		String packetData = "10101010 10101010 10101010 10101010 0000000";
		String packetData = "10101010 10101010 10101010 10101010";
		String actualData = packetData.replaceAll("\\s", ""); 
		System.out.println("Packet Data " + packetData);
		System.out.println("Actual Data " + actualData);
		long toLong = Long.parseLong(actualData, 2);
		System.out.println(Long.toString(toLong, 16));

		byte firstByte;
		byte secondByte;
		//byte resultByte = (byte) ((byte) firstByte ^ secondByte);
		//System.out.println(resultByte);
		
		for(int i = 0; i < 8; i++) {
			for(int j = 1; j <= 7; j++) {
				if(j <= i)
					continue;
				firstByte	= Byte.parseByte(bit[i], 2);
				secondByte	= Byte.parseByte(bit[j], 2);
				byte resultByte = (byte) ((byte) firstByte ^ secondByte);
				
				System.out.println(Integer.toString(firstByte, 2) + " + " +
					Integer.toString(secondByte, 2) + " = " +
					Integer.toString(resultByte, 2)
				);
				//System.out.println(resultByte);
			}
		}
		
		
	}	

}
