package com.networkdesign.cmpe;

public class IPValidator {
	
	String ipAddress;	
	
	public IPValidator(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	
	public String getIpAddress() {
		return ipAddress;
	}
	
	
	// Checks and validates IP address
	public static boolean checkIP(String ipAddress) {
		
		String[] num = ipAddress.split("\\.");

		if (num.length != 4)
			return false;

		for (String str : num) {
			int i = Integer.parseInt(str);
			if ((i < 0) || (i > 255))
				return false;
		}

		return true;

	} // End of checkIP method

	public static byte[] convertToIP(String ipAddress) {

		// Holds the IP address once string has been converted
		byte ipAddr[] = new byte[4];

		String[] num = ipAddress.split("\\.");
		int count = 0;

		for (String str : num) {
			int i = Integer.parseInt(str);
			ipAddr[count] = (byte) i;
			count++;
		}

		return ipAddr;
	} // End of converToIP method
}
