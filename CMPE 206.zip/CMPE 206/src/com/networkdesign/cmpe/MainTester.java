package com.networkdesign.cmpe;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainTester {
	
	public static void main(String args[]) {
		
		System.out.println(subIPAddresses("192.168.29.26"));
		
		//ipScan("192.168.29.26-192.168.29.80");
		ipScan("172.217.5.206-172.217.5.216");
		
		//	System.out.println(incSubIP("192.168.29.26"));
		/*for (int i = 0; i < 100; i++) 
			System.out.println(incSubIP("192.168.29.26"));*/
		
		/*
		for(int count = 0; count < 10; count++)
			System.out.println(genString());
		Scanner in = new Scanner(System.in);
		String input = in.nextLine();
		
		String arguments[] = input.split(" ");
		
		if(validateURL(arguments[0]))
			System.out.println("Successful");
		
		try {
			sendGet();
		} catch (Exception e) {
			e.printStackTrace();
			
		}*/
	}
	
	public static void ipScan(String keyWds) {
		String ipAddressRange[] = keyWds.split("-"); 
		int length, first, second;
		
		/*System.out.println(keyWds + " Next is for loop");
		for (String ips : ipAddressRange)
			System.out.println(ips);*/
				
		first	= subIPAddresses(ipAddressRange[0]);
		second	= subIPAddresses(ipAddressRange[1]);
		length = second - first;
		
		//System.out.println(length);
		
		Process p;
		int count		= 0;
		String firstIP	= ipAddressRange[0];
		String tempIP;
		StringBuilder st = new StringBuilder();
		
		while(count < length) {
			//System.out.println(incSubIP(firstIP));
			try {
				p = Runtime.getRuntime().exec("ping " + firstIP);
				
				BufferedReader inputStream = new BufferedReader(
					new InputStreamReader(
					p.getInputStream()));

		        String commandOutput = "";
		        boolean isReachable = true;
		        // reading output stream of the command
		        while ((commandOutput = inputStream.readLine()) != null) {
		        	//	System.out.println(commandOutput);
		            
		            if(commandOutput.contains("Destination host unreachable")) {
		                isReachable = false;
		                break;
		            }
		                    
		        }
		        
		        if(isReachable) {
		        	System.out.println("Host is reachable!");
		        	count++;
		        	if (count == length) {
		        		st.append(firstIP);
		        		break;
		        	}
		        		
		        	st.append(firstIP + ", ");
		        } else
		        	System.out.println("Host is not reachable!");
		    } catch (IOException e) {
				e.printStackTrace();
			}
			firstIP = incSubIP(firstIP);
			//	count++;
		}
		System.out.println(st);
		//Thread t = new Thread();
	}
	
	public static String incSubIP(String ipAddress) {
		String incremented = null;
		
		// System.out.println(ipAddress);
		
		String nums[] = ipAddress.split("\\.");
		
		/*for (String num : nums)
			System.out.println(num);*/
		
		int plusIP = Integer.parseInt(nums[3]);
		plusIP++;
		
		incremented = nums[0] + "." + nums[1] + "." + nums[2] + "." + Integer.toString(plusIP);
		
		return incremented;
	}
	
	// Sub IP Address
	private static int subIPAddresses(String ipAddress) {
			
		//Holds the IP address once string has been converted
		byte ipAddr[] = new byte[4];
		
		String[] num = ipAddress.split("\\.");
        int count	= 0;
        int subNet	= 0;
		
        for(String str : num) {
        	if (count == 3) {
        		subNet = Integer.parseInt(str);
        	}
        	
        	count++;
        }
		
		return subNet;		
	} // End of converToIP method
	
	private static boolean validateURL(String url) {
		
		String urlToVerify = "^((https?|ftp)://|(www|ftp)\\.)?[a-z0-9-]+(\\.[a-z0-9-]+)+([/?].*)?$";

		Pattern p = Pattern.compile(urlToVerify);
		Matcher m = p.matcher(url);//replace with string to compare
		if(m.find()) {
		    System.out.println("String contains URL");
		    return true;
		}
		return false;
	}
	
	private static String genString() {
		
		String alphaNum = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("/#q=");				
		
		Random rndNum	 = new Random();
		Random rndString = new Random();
		
		int numOfChars = rndNum.nextInt(10);
		int totalLength = numOfChars + stringBuilder.length() + 1;		
		
		while (stringBuilder.length() < totalLength) {
			int index = (int) (rndString.nextFloat() * alphaNum.length() );
			stringBuilder.append(alphaNum.charAt(index));
		}
		
		String appendToURL = stringBuilder.toString();
		return appendToURL;
	}
	
	private static void sendGet() throws Exception {

		String USER_AGENT = "Mozilla/5.0";		
		String url = "http://www.google.com/search?q=mkyong";

		URL obj = new URL(url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");

		// add request header
		con.setRequestProperty("User-Agent", USER_AGENT);

		int responseCode = con.getResponseCode();
		System.out.println("\nSending 'GET' request to URL : " + url);
		System.out.println("Response Code : " + responseCode);
	}
}
