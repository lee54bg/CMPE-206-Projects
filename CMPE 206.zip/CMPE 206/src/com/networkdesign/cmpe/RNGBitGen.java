package com.networkdesign.cmpe;
import java.util.Random;

public class RNGBitGen {
	public static void main(String argsp[]) {
		Random rand = new Random();
				
		for(int i = 0; i < 2; i++) {
			int x = rand.nextInt(256);
			System.out.println(Integer.toBinaryString(x));
		}
	}
}
