package com.networkdesign.cmpe;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class SecondServer {

	public static void main(String[] args) {
		PrintWriter out ;
		BufferedReader input;
		
		try
        {
            ServerSocket serverSocket = new ServerSocket(134);
            System.out.println("wainting for clients...");
            boolean stop = false;
            
            
            Socket socket = serverSocket.accept();
            out		= new PrintWriter(socket.getOutputStream(), true);
            input	= new BufferedReader(new InputStreamReader(System.in));
            
            String cmdArgs[] = null;
            
            System.out.println(socket.getPort() + " " + socket.getInetAddress().getHostAddress());
            
            while(true) {
            	System.out.print(">");
    			
    			String cmdPrmpt = input.readLine();
    			cmdArgs = cmdPrmpt.split(" ");    			
    			
    			for(String cmds : cmdArgs) {
    				System.out.println(cmds);
    			}
    			
    			if(cmdArgs.length == 3) {
    				String clientAddress = cmdArgs[1];
    				int portNum = Integer.parseInt(cmdArgs[2]);
    				
    				socket = new Socket(clientAddress, portNum);
    			}
    			
    			if(cmdArgs[0].toLowerCase().equals("exit")) {
    				System.out.println("Terminating Program");
    				break;
    			}
    		}
            
            input.close();
            out.close();
            socket.close();
            serverSocket.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
}
