package com.networkdesign.cmpe;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {

	public static void main(String[] args) {
		PrintWriter out ;
		BufferedReader input;
		
		try
        {
            ServerSocket serverSocket = new ServerSocket(3000);
            System.out.println("wainting for clients...");
            boolean stop = false;
            
            
            Socket socket = serverSocket.accept();
            out		= new PrintWriter(socket.getOutputStream(), true);
            input	= new BufferedReader(new InputStreamReader(System.in));
            
            String cmdArgs[] = null;
            
            System.out.println("Client:\t" + socket.getPort() + "\t" + socket.getInetAddress().getHostAddress());
            
            while(true) {
            	System.out.print(">");
    			
    			String cmdPrmpt = input.readLine();
    			cmdArgs = cmdPrmpt.split(" ");
    			
    			out.println(cmdPrmpt);
    			
    			if(cmdArgs[0].toLowerCase().equals("exit")) {
    				System.out.println("Terminating Program");
    				break;
    			}
    		}
            
            input.close();
            out.close();
            socket.close();
            serverSocket.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	
}
