package com.networkdesign.cmpe;
/*
 * Author: Brandon Lee Gaerlan
 * Program: Create a program that connects a SlaveBot to a MasterBot
 * The master must have the following specified commands as noted in the Programming Project requirements
 * Due Date: 03-06-2017
 * */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class SlaveBotThread extends Thread {
	
	Socket slaveSocket = null;
	PrintWriter out;
	BufferedReader in;
	
	public SlaveBotThread(Socket client) {
		this.slaveSocket = client;
	}
	
	public void run() {
		try {
			out = new PrintWriter(slaveSocket.getOutputStream(), true);
	        in  = new BufferedReader(
	        	new InputStreamReader(
	        	slaveSocket.getInputStream() ) );
	        
	        String clientInput = in.readLine();
	        
	        System.out.println(clientInput);
	        closeConnection();
		} catch (Exception e) {
	        System.out.println(">" + e.toString());
	    }
	}
	
	//Closing connections
	public void closeConnection() {
        try {
			in.close();
			out.close();
			slaveSocket.close();
		} catch (IOException e) {
		}
        
	}
}
